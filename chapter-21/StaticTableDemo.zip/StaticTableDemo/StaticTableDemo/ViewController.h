//
//  ViewController.h
//  StaticTableDemo
//
//  Created by Simon on 17/11/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
