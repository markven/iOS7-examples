//
//  RecipeStoreTableViewController.h
//  RecipeStore
//
//  Created by Simon on 12/1/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeStoreTableViewController : UITableViewController

@end
