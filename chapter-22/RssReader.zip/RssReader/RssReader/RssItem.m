//
//  RssItem.m
//  RssReader
//
//  Created by Simon on 29/12/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import "RssItem.h"

@implementation RssItem

@end
