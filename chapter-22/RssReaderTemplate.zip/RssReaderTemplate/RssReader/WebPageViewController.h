//
//  WebPageViewController.h
//  RssReader
//
//  Created by Simon on 29/12/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebPageViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
