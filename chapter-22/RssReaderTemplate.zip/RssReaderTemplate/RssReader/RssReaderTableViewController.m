//
//  RssReaderViewTableController.m
//  RssReader
//
//  Created by Simon on 29/12/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import "RssReaderTableViewController.h"

@interface RssReaderTableViewController ()

@end

@implementation RssReaderTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
