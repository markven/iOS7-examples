//
//  BookStoreViewController.h
//  BookStore
//
//  Created by Simon on 17/1/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookStoreViewController : UIViewController
- (IBAction)buy:(id)sender;

@end
