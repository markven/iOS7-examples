//
//  main.m
//  BookStore
//
//  Created by Simon on 17/1/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BookStoreAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BookStoreAppDelegate class]));
    }
}
