//
//  main.m
//  SimpleTable
//
//  Created by Simon on 1/12/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SimpleTableAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SimpleTableAppDelegate class]));
    }
}
